import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http'

import { ThumbnailComponent } from './components/thumbnail/thumbnail.component';
import {MovieService} from './movie-service.service';
import { PopularComponent } from './components/popular/popular.component';
import { TopRatedComponent } from './components/top-rated/top-rated.component'
@NgModule({
  declarations: [ThumbnailComponent, PopularComponent, TopRatedComponent],
  imports: [
    CommonModule,
    HttpClientModule
  ],
  exports:[ThumbnailComponent,PopularComponent,TopRatedComponent],
  providers:[MovieService]
})
export class MovieModule { }
