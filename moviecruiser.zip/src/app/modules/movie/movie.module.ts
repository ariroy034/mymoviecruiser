import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http'
import { MatCardModule } from '@angular/material/card';
import{ MatButtonModule } from '@angular/material/button';
import { MatSnackBarModule } from '@angular/material/snack-bar';

import { ThumbnailComponent } from './components/thumbnail/thumbnail.component';
import {MovieService} from './movie-service.service';
import { ContainerComponent } from './components/container/container.component';
import { MovieRouterModule } from './movie-router.module';
import { WatchListComponent } from './components/watchlist/watchlist.component';
import { TmdbContainerComponent } from './components/tmdb-container/tmdb-container.component'

@NgModule({
  declarations: [ThumbnailComponent, ContainerComponent, WatchListComponent, TmdbContainerComponent],
  imports: [
    CommonModule,
    HttpClientModule,
    MatCardModule,
    MatButtonModule,
    MatSnackBarModule
  ],
  exports:[ThumbnailComponent,ContainerComponent,MovieRouterModule],
  providers:[MovieService]
})
export class MovieModule { }
