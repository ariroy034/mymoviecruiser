import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http'
import { MatCardModule } from '@angular/material/card';
import{ MatButtonModule } from '@angular/material/button';
import { MatSnackBarModule } from '@angular/material/snack-bar';
import { MatFormFieldModule,MatInputModule } from '@angular/material';
import { FormsModule } from '@angular/forms';

import { ThumbnailComponent } from './components/thumbnail/thumbnail.component';
import {MovieService} from './movie-service.service';
import { ContainerComponent } from './components/container/container.component';
import { MovieRouterModule } from './movie-router.module';
import { WatchListComponent } from './components/watchlist/watchlist.component';
import { TmdbContainerComponent } from './components/tmdb-container/tmdb-container.component';
import { SearchComponent } from './components/search/search.component';
import { MovieDialogComponent } from './components/movie-dialog/movie-dialog.component';


@NgModule({
  declarations: [ThumbnailComponent, ContainerComponent, WatchListComponent, TmdbContainerComponent, SearchComponent, MovieDialogComponent],
  imports: [
    CommonModule,
    HttpClientModule,
    MatCardModule,
    MatButtonModule,
    MatSnackBarModule,
    MatFormFieldModule,
    MatInputModule,
    FormsModule
  ],
  exports:[ThumbnailComponent,ContainerComponent,MovieRouterModule,MovieDialogComponent],
  entryComponents: [MovieDialogComponent],
  providers:[MovieService],
})
export class MovieModule { }
