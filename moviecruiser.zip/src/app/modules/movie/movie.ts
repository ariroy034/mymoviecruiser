export interface Movie{
    title:string;
    poster_path:string;
    overview:string;
    released_date:string;
};