import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { map } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { retry } from 'rxjs/operators'

import { Movie } from './movie'
@Injectable({
  providedIn: 'root'
})
export class MovieService {
  tmdbEndPoint:string;
  imagePrefix:string;
  apiKey:string;
  springEndPoint:string;

  constructor(private http:HttpClient) { 
    this.apiKey='api_key=4f5ef5c928dea6df91088949785e0171';
    this.tmdbEndPoint='https://api.themoviedb.org/3/movie';
    this.imagePrefix='https://image.tmdb.org/t/p/w500';
    this.springEndPoint='http://localhost:8085/api/movie';
  }

  addMovieToWatchList(movie){
    return this.http.post(this.springEndPoint, movie);
  }
  getMovieFromWatchList(): Observable<Array<Movie>>{
    return this.http.get<Array<Movie>>(this.springEndPoint);
  }
  deleteFromWatchList(movie:Movie){
    const url= `${this.springEndPoint}/${movie.id}`
    return this.http.delete(url,{responseType:'text'});
  }
  getMovies(type:string,page:number=1):Observable<Array<Movie>>{
    const endPoint=`${this.tmdbEndPoint}/${type}?${this.apiKey}&page=${page}`;
     return this.http.get(endPoint).pipe(
      retry(3),
      map(this.pickMovieResults),
      map(this.transformPosterPath.bind(this))
    );
  }
  transformPosterPath(movies):Array<Movie>{
    return movies.map(movie => {
      movie.poster_path=`${this.imagePrefix}${movie.poster_path}`;
      return movie;
    })
    
  }
  pickMovieResults(response) {
    return response['results'];
  }
}
