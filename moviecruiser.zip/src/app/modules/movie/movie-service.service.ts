import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { map } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { retry } from 'rxjs/operators'

import { Movie } from './movie'
@Injectable({
  providedIn: 'root'
})
export class MovieService {
  tmdbEndPoint:string;
  imagePrefix:string;
  apiKey:string;
  constructor(private http:HttpClient) { 
    this.apiKey='api_key=4f5ef5c928dea6df91088949785e0171';
    this.tmdbEndPoint='https://api.themoviedb.org/3/movie';
    this.imagePrefix='https://image.tmdb.org/t/p/w500'
  }

  getTopRatedMovies(page:number=1): Observable<Array<Movie>>{
    const topRatedMoviesEndPoint=`${this.tmdbEndPoint}/top_rated?${this.apiKey}&page=${page}`;
    return this.http.get(topRatedMoviesEndPoint).pipe(
      retry(3),
      map(this.pickMovieResults),
      map(this.transformPosterPath.bind(this))
    );
  }
  getPopularMovies(page:number=1): Observable<Array<Movie>>{
    const popularMoviesEndPoint=`${this.tmdbEndPoint}/popular?${this.apiKey}&page=${page}`;
    return this.http.get(popularMoviesEndPoint).pipe(
      retry(3),
      map(this.pickMovieResults),
      map(this.transformPosterPath.bind(this))
    );
  }
  transformPosterPath(movies):Array<Movie>{
    return movies.map(movie => {
      movie.poster_path=`${this.imagePrefix}${movie.poster_path}`;
      return movie;
    })
    
  }
  pickMovieResults(response) {
    return response['results'];
  }
}
