import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';

import {MovieService} from '../../movie-service.service'
import { Movie } from '../../movie';
@Component({
  selector: 'movie-watchlist',
  templateUrl: './watchlist.component.html',
  styleUrls: ['./watchlist.component.css']
})
export class WatchListComponent implements OnInit {
movies:Array<Movie>;
useWatchListApt=true;
  constructor(private movieService:MovieService, private matSnackBar:MatSnackBar) {
    this.movies=[];
   }

  ngOnInit() {
    let message="Watchlist is empty";
    this.movieService.getMovieFromWatchList().subscribe(movies=>{
      if(movies.length==0){
        this.matSnackBar.open(message,"",{
          duration:1000
        })
      }
      this.movies.push(...movies);
    });
  }

}
