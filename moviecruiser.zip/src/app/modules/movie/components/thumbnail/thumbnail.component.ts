import { Component, OnInit, Input,Output,EventEmitter} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatDialog,MatDialogRef,MAT_DIALOG_DATA } from '@angular/material';

import { Movie } from '../../movie';
import {MovieService} from '../../movie-service.service'
@Component({
  selector: 'movie-thumbnail',
  templateUrl: './thumbnail.component.html',
  styleUrls: ['./thumbnail.component.css']
})
export class ThumbnailComponent implements OnInit {
  @Input()
  movie: Movie;
  @Input()
  useWatchListApt:boolean;

  @Output()
  addMovie=new EventEmitter();
  @Output()
  deleteMovie=new EventEmitter();
  @Output()
  updateMovie=new EventEmitter();
  constructor() { 
   
  }

  ngOnInit() {
    
  }

  addToWatchList(){
    this.addMovie.emit(this.movie);
   
  }
  deleteFromWatchList(){
    this.deleteMovie.emit(this.movie);
  }
  updateWatchList(){

  }

}
