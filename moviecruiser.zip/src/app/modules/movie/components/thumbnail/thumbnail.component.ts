import { Component, OnInit, Input,Output,EventEmitter} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatDialog,MatDialogRef,MAT_DIALOG_DATA } from '@angular/material';

import { Movie } from '../../movie';
import {MovieService} from '../../movie-service.service'
import { MovieDialogComponent } from '../movie-dialog/movie-dialog.component';
@Component({
  selector: 'movie-thumbnail',
  templateUrl: './thumbnail.component.html',
  styleUrls: ['./thumbnail.component.css']
})
export class ThumbnailComponent implements OnInit {
  @Input()
  movie: Movie;
  @Input()
  useWatchListApt:boolean;

  @Output()
  addMovie=new EventEmitter();
  @Output()
  deleteMovie=new EventEmitter();
  @Output()
  updateMovie=new EventEmitter();
  constructor(private matSnackBar:MatSnackBar,private dialog:MatDialog) { 
   
  }

  ngOnInit() {
    
  }

  addToWatchList(){
    this.addMovie.emit(this.movie);
   
  }
  deleteFromWatchList(){
    this.deleteMovie.emit(this.movie);
  }
  updateWatchList(actionType){
    let dialogRef=this.dialog.open(MovieDialogComponent,{
      width:'400px',
      data:{Obj:this.movie,actionType:actionType}
    });
    dialogRef.afterClosed().subscribe(result=>{
      console.log("dialog closed");
    });
  }

}
