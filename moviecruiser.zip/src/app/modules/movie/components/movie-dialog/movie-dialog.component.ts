import { Component, OnInit, Inject } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { MatSnackBar } from '@angular/material';

import {MovieService} from '../../movie-service.service';
import { Movie } from '../../movie';

@Component({
  selector: 'movie-movie-dialog',
  templateUrl: './movie-dialog.component.html',
  styleUrls: ['./movie-dialog.component.css']
})
export class MovieDialogComponent implements OnInit {
  movie:Movie;
  comments:string;
  actionType:String;
  constructor(public snackBar:MatSnackBar,public dialogRef:MatDialogRef<MovieDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data:any,private movieService:MovieService) { 
      this.comments=data.object.movieComments;
      this.movie=data.object;
      this.actionType=data.actionType;
    }

  ngOnInit() {
  }

}
