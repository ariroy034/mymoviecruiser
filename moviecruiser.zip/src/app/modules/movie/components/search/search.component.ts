import { Component, OnInit } from '@angular/core';
import { Movie } from '../../movie';
import { MovieService } from '../../movie-service.service';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'movie-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  movies:Array<Movie>;
  constructor(private movieService:MovieService,private snackBar:MatSnackBar) { }

  ngOnInit() {
  }
  onEnter(searchKey){
    console.log("searchKey",searchKey);
    this.movieService.searchMovies(searchKey).subscribe(movies=>{
      this.movies=movies;
      let message=`${this.movies.length} movies found`;
      this.snackBar.open(message,"",{
        duration:1000
      });
    })
  }

}
