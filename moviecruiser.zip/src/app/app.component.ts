import { Component } from '@angular/core';
import { ThumbnailComponent } from './modules/movie/components/thumbnail/thumbnail.component';
@Component({
  selector: 'app-root',
  template:
  `<movie-top-rated></movie-top-rated>`,
  styles:[]
})
export class AppComponent {
  title = 'moviecruiser';
}
