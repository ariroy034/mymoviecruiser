import { Component } from '@angular/core';
import { ThumbnailComponent } from './modules/movie/components/thumbnail/thumbnail.component';
@Component({
  selector: 'app-root',
  template:
  `
  <mat-toolbar color=primary>
  <span>Movie Cruiser App</span>
  <button mat-button [routerLink]="['./movies/popular']">Popular Movies</button>
  <button mat-button [routerLink]="['./movies/top_rated']">Top Rated Movies</button>
  <button mat-button [routerLink]="['./movies/watchlist']">My Watchlist</button>
  <button mat-button [routerLink]="['./movies/search']">Search</button>

  </mat-toolbar>
  <router-outlet></router-outlet>`,
  styles:[]
})
export class AppComponent {
  title = 'moviecruiser';
}
